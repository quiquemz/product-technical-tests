export default function() {
    return [
        {_id: 1, slug: 'abcd', name: 'test1', location: {lat: 1, lon: 0}},
        {_id: 2, slug: 'efgh', name: 'test2', location: {lat: 1, lon: 0}}
    ];
}
