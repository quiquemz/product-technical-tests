export default function boutiques({models}, req, res, next) {
    res.status(500).send();
}
