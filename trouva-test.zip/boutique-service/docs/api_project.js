define({
  "name": "boutique-service",
  "version": "0.0.1",
  "description": "HTTP API to the boutique-service",
  "apidoc": "0.3.0",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-05-09T07:26:50.818Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
